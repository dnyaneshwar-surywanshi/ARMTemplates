# Introduction 
TODO: Give a short introduction of your project. Let this section explain the objectives or the motivation behind this project. 

# Getting Started
TODO: Guide users through getting your code up and running on their own system. In this section you can talk about:
1.	Installation process
2.	Software dependencies
3.	Latest releases
4.	API references

# Build and Test
TODO: Describe and show how to build your code and run the tests. 

# Contribute
TODO: Explain how other users and developers can contribute to make your code better. 

If you want to learn more about creating good readme files then refer the following [guidelines](https://docs.microsoft.com/en-us/azure/devops/repos/git/create-a-readme?view=azure-devops). You can also seek inspiration from the below readme files:
- [ASP.NET Core](https://github.com/aspnet/Home)
- [Visual Studio Code](https://github.com/Microsoft/vscode)
- [Chakra Core](https://github.com/Microsoft/ChakraCore)

# Issues / Problems / Troubleshooting

### The variable in the VG appGwMaxCapacity has a range for 2-125 ONLY. 
  - A setting of 0 or 1 will cause a fault/error in deployment and cancel it. 
  - 2020-05-20 the buildsheet allows values of less than 2 which needs to be updated to remove those to not cause errors
  - An example error = "ApplicationGatewayInvalidCapacityInAutoscaleConfiguration: Application Gateway /subscriptions/X/resourceGroups/X/providers/Microsoft.Network/applicationGateways/X does not have valid MaxCapacity value for AutoscaleConfiguration. Valid value is in the range of [2-125]" 

### TBA
